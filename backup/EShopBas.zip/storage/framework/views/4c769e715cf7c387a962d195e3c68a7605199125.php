<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <style>
        html, body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway', sans-serif;
            font-weight: 100;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
<div class="flex-center position-ref full-height">
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>
                <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
        </div>
    <?php endif; ?>
    <div id="player" style="width: 100%; height: 100%;">
        <div class="html5-video-player unstarted-mode ytp-hide-controls ytp-small-mode" tabindex="-1"
             id="player_uid_627530490_1" data-version="/yts/jsbin/player-vfl8swg2e/ru_RU/base.js"
             aria-label="Проигрыватель YouTube">
            <div class="html5-video-container" data-layer="0">
                <video tabindex="-1" class="video-stream html5-main-video" controlslist="nodownload"
                       style="width: 367px; height: 201px; left: 0px; top: -201px;"></video>
            </div>
            <div class="ytp-gradient-top" data-layer="1"></div>
            <div class="ytp-chrome-top ytp-share-button-visible" data-layer="1">
                <button class="ytp-playlist-menu-button ytp-button ytp-playlist-menu-button-tiny" aria-owns="ytp-id-2"
                        aria-haspopup="true" aria-label="Плейлист" style="display: none;">
                    <div class="ytp-playlist-menu-button-icon">
                        <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                            <use class="ytp-svg-shadow" xmlns:xlink="http://www.w3.org/1999/xlink"
                                 xlink:href="#ytp-id-3"></use>
                            <path d="m 22.53,21.42 0,6.85 5.66,-3.42 -5.66,-3.42 0,0 z m -11.33,0 9.06,0 0,2.28 -9.06,0 0,-2.28 0,0 z m 0,-9.14 13.6,0 0,2.28 -13.6,0 0,-2.28 0,0 z m 0,4.57 13.6,0 0,2.28 -13.6,0 0,-2.28 0,0 z"
                                  fill="#fff" id="ytp-id-3"></path>
                        </svg>
                    </div>
                    <div class="ytp-playlist-menu-button-text"></div>
                </button>
                <div class="ytp-title" data-visual-id="1">
                    <div class="ytp-title-channel"><a class="ytp-title-channel-logo" target="_blank"
                                                      data-visual-id="2"></a>
                        <div class="ytp-title-channel-popup">
                            <div class="ytp-title-channel-heading"><h2 class="ytp-title-channel-text"><a
                                            target="_blank"></a></h2>
                                <h3 class="ytp-title-channel-subtext"></h3></div>
                        </div>
                    </div>
                    <div class="ytp-title-text"><a class="ytp-title-link yt-uix-sessionlink" target="_blank"
                                                   data-sessionlink="feature=player-title"
                                                   href="https://www.youtube.com/watch?v=Qf8rjN7DxFk">Responsive Browser
                            App Script Template HTML5 CSS3 Javascript PhoneGap</a>
                        <div class="ytp-title-subtext"><a class="ytp-title-channel-name" target="_blank"></a><span
                                    class="ytp-title-view-count"></span></div>
                    </div>
                </div>
                <div class="ytp-chrome-top-buttons">
                    <button class="ytp-watch-later-button ytp-button" data-tooltip-opaque="false" data-visual-id="3"
                            title="Просмотреть позже как Дмитрий Мисюля"
                            data-tooltip-image="https://lh3.googleusercontent.com/-CIIsGdSZhgA/AAAAAAAAAAI/AAAAAAAADec/mvaHk_Kjb3o/photo.jpg">
                        <div class="ytp-watch-later-icon">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                                <use class="ytp-svg-shadow" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     xlink:href="#ytp-id-4"></use>
                                <path class="ytp-svg-fill"
                                      d="M18,8 C12.47,8 8,12.47 8,18 C8,23.52 12.47,28 18,28 C23.52,28 28,23.52 28,18 C28,12.47 23.52,8 18,8 L18,8 Z M16,19.02 L16,12.00 L18,12.00 L18,17.86 L23.10,20.81 L22.10,22.54 L16,19.02 Z"
                                      id="ytp-id-4"></path>
                            </svg>
                        </div>
                        <div class="ytp-watch-later-title"></div>
                    </button>
                    <button class="ytp-button ytp-share-button" title="Поделиться" aria-haspopup="true"
                            aria-owns="ytp-id-6" data-tooltip-opaque="false" data-visual-id="4">
                        <div class="ytp-share-icon">
                            <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                                <use class="ytp-svg-shadow" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     xlink:href="#ytp-id-7"></use>
                                <path class="ytp-svg-fill"
                                      d="m 20.20,14.19 0,-4.45 7.79,7.79 -7.79,7.79 0,-4.56 C 16.27,20.69 12.10,21.81 9.34,24.76 8.80,25.13 7.60,27.29 8.12,25.65 9.08,21.32 11.80,17.18 15.98,15.38 c 1.33,-0.60 2.76,-0.98 4.21,-1.19 z"
                                      id="ytp-id-7"></path>
                            </svg>
                        </div>
                        <div class="ytp-share-title"></div>
                    </button>
                    <button class="ytp-button ytp-cards-button" aria-label="Показать подсказки" aria-owns="iv-drawer"
                            aria-haspopup="true" data-tooltip-opaque="false" style="display: none;"><span
                                class="ytp-cards-button-icon-default"><div class="ytp-cards-button-icon"><svg
                                        height="100%" version="1.1" viewBox="0 0 36 36" width="100%"><use
                                            class="ytp-svg-shadow" xmlns:xlink="http://www.w3.org/1999/xlink"
                                            xlink:href="#ytp-id-8"></use><path class="ytp-svg-fill"
                                                                               d="M18,8 C12.47,8 8,12.47 8,18 C8,23.52 12.47,28 18,28 C23.52,28 28,23.52 28,18 C28,12.47 23.52,8 18,8 L18,8 Z M17,16 L19,16 L19,24 L17,24 L17,16 Z M17,12 L19,12 L19,14 L17,14 L17,12 Z"
                                                                               id="ytp-id-8"></path></svg></div><div
                                    class="ytp-cards-button-title">О видео</div></span><span
                                class="ytp-cards-button-icon-shopping"><div class="ytp-cards-button-icon"><svg
                                        height="100%" version="1.1" viewBox="0 0 36 36" width="100%"><path
                                            class="ytp-svg-shadow"
                                            d="M 27.99,18 A 9.99,9.99 0 1 1 8.00,18 9.99,9.99 0 1 1 27.99,18 z"></path><path
                                            class="ytp-svg-fill"
                                            d="M 18,8 C 12.47,8 8,12.47 8,18 8,23.52 12.47,28 18,28 23.52,28 28,23.52 28,18 28,12.47 23.52,8 18,8 z m -4.68,4 4.53,0 c .35,0 .70,.14 .93,.37 l 5.84,5.84 c .23,.23 .37,.58 .37,.93 0,.35 -0.13,.67 -0.37,.90 L 20.06,24.62 C 19.82,24.86 19.51,25 19.15,25 c -0.35,0 -0.70,-0.14 -0.93,-0.37 L 12.37,18.78 C 12.13,18.54 12,18.20 12,17.84 L 12,13.31 C 12,12.59 12.59,12 13.31,12 z m .96,1.31 c -0.53,0 -0.96,.42 -0.96,.96 0,.53 .42,.96 .96,.96 .53,0 .96,-0.42 .96,-0.96 0,-0.53 -0.42,-0.96 -0.96,-0.96 z"
                                            fill-opacity="1"></path><path class="ytp-svg-shadow-fill"
                                                                          d="M 24.61,18.22 18.76,12.37 C 18.53,12.14 18.20,12 17.85,12 H 13.30 C 12.58,12 12,12.58 12,13.30 V 17.85 c 0,.35 .14,.68 .38,.92 l 5.84,5.85 c .23,.23 .55,.37 .91,.37 .35,0 .68,-0.14 .91,-0.38 L 24.61,20.06 C 24.85,19.83 25,19.50 25,19.15 25,18.79 24.85,18.46 24.61,18.22 z M 14.27,15.25 c -0.53,0 -0.97,-0.43 -0.97,-0.97 0,-0.53 .43,-0.97 .97,-0.97 .53,0 .97,.43 .97,.97 0,.53 -0.43,.97 -0.97,.97 z"
                                                                          fill="#000" fill-opacity="0.15"></path></svg></div><div
                                    class="ytp-cards-button-title">Покупки</div></span></button>
                    <div class="ytp-cards-teaser" style="display: none;">
                        <div class="ytp-cards-teaser-box"></div>
                        <div class="ytp-cards-teaser-text"><span class="ytp-cards-teaser-label"></span></div>
                    </div>
                </div>
            </div>
            <button class="ytp-unmute ytp-popup ytp-button ytp-unmute-animated ytp-unmute-shrink" data-layer="2"
                    style="display: none;">
                <div class="ytp-unmute-inner">
                    <div class="ytp-unmute-icon">
                        <svg height="100%" version="1.1" viewBox="0 0 36 36" width="100%">
                            <use class="ytp-svg-shadow" xmlns:xlink="http://www.w3.org/1999/xlink"
                                 xlink:href="#ytp-id-1"></use>
                            <path class="ytp-svg-fill"
                                  d="m 21.48,17.98 c 0,-1.77 -1.02,-3.29 -2.5,-4.03 v 2.21 l 2.45,2.45 c .03,-0.2 .05,-0.41 .05,-0.63 z m 2.5,0 c 0,.94 -0.2,1.82 -0.54,2.64 l 1.51,1.51 c .66,-1.24 1.03,-2.65 1.03,-4.15 0,-4.28 -2.99,-7.86 -7,-8.76 v 2.05 c 2.89,.86 5,3.54 5,6.71 z M 9.25,8.98 l -1.27,1.26 4.72,4.73 H 7.98 v 6 H 11.98 l 5,5 v -6.73 l 4.25,4.25 c -0.67,.52 -1.42,.93 -2.25,1.18 v 2.06 c 1.38,-0.31 2.63,-0.95 3.69,-1.81 l 2.04,2.05 1.27,-1.27 -9,-9 -7.72,-7.72 z m 7.72,.99 -2.09,2.08 2.09,2.09 V 9.98 z"
                                  id="ytp-id-1"></path>
                        </svg>
                    </div>
                    <div class="ytp-unmute-text">Включить звук</div>
                    <div class="ytp-unmute-box"></div>
                </div>
            </button>
            <div class="ytp-cued-thumbnail-overlay" data-layer="4" style="">
                <div class="ytp-cued-thumbnail-overlay-image"
                     style="background-image: url(&quot;https://i.ytimg.com/vi_webp/Qf8rjN7DxFk/sddefault.webp&quot;);"></div>
                <button class="ytp-large-play-button ytp-button" aria-label="Смотреть">
                    <svg height="100%" version="1.1" viewBox="0 0 68 48" width="100%">
                        <path class="ytp-large-play-button-bg"
                              d="M66.52,7.74c-0.78-2.93-2.49-5.41-5.42-6.19C55.79,.13,34,0,34,0S12.21,.13,6.9,1.55 C3.97,2.33,2.27,4.81,1.48,7.74C0.06,13.05,0,24,0,24s0.06,10.95,1.48,16.26c0.78,2.93,2.49,5.41,5.42,6.19 C12.21,47.87,34,48,34,48s21.79-0.13,27.1-1.55c2.93-0.78,4.64-3.26,5.42-6.19C67.94,34.95,68,24,68,24S67.94,13.05,66.52,7.74z"
                              fill="#212121" fill-opacity="0.8"></path>
                        <path d="M 45,24 27,14 27,34" fill="#fff"></path>
                    </svg>
                </button>
            </div>
            <div class="ytp-spinner" data-layer="4" style="display: none;">
                <div>
                    <div class="ytp-spinner-container">
                        <div class="ytp-spinner-rotator">
                            <div class="ytp-spinner-left">
                                <div class="ytp-spinner-circle"></div>
                            </div>
                            <div class="ytp-spinner-right">
                                <div class="ytp-spinner-circle"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ytp-spinner-message" style="display: none;">Подождите немного. Если воспроизведение так и не
                    начнется, перезагрузите устройство.
                </div>
            </div>
            <div class="ytp-bezel" role="status" data-layer="4" style="display: none;">
                <div class="ytp-bezel-icon"></div>
            </div>
            <div class="ytp-paid-content-overlay" aria-live="assertive" aria-atomic="true" data-layer="4">
                <div class="ytp-button ytp-paid-content-overlay-text" style="display: none;"></div>
            </div>
            <div data-layer="4" style="display: none;">
                <div class="ytp-tooltip-bg">
                    <div class="ytp-tooltip-duration"></div>
                </div>
                <div class="ytp-tooltip-text-wrapper">
                    <div class="ytp-tooltip-image"></div>
                    <div class="ytp-tooltip-title"></div>
                    <span class="ytp-tooltip-text"></span></div>
            </div>
            <div class="ytp-ad-persistent-progress-bar-container" style="display: none;" data-layer="4">
                <div class="ytp-ad-persistent-progress-bar"></div>
            </div>
            <div class="ytp-playlist-menu" role="dialog" id="ytp-id-2" data-layer="5" style="display: none;">
                <div class="ytp-playlist-menu-header">
                    <div class="ytp-playlist-menu-title"><a class="ytp-playlist-menu-title-name"></a>
                        <button class="ytp-playlist-menu-close ytp-button" aria-label="Закрыть">
                            <svg height="100%" viewBox="0 0 24 24" width="100%">
                                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
                                      fill="#fff"></path>
                            </svg>
                        </button>
                    </div>
                    <div class="ytp-playlist-menu-subtitle"></div>
                </div>
                <div class="ytp-playlist-menu-items" role="menu"></div>
            </div>
            <div class="ytp-share-panel" id="ytp-id-6" role="dialog" aria-labelledby="ytp-id-5" data-layer="5"
                 style="display: none;">
                <button class="ytp-share-panel-close ytp-button" title="Закрыть">
                    <svg height="100%" viewBox="0 0 24 24" width="100%">
                        <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
                              fill="#fff"></path>
                    </svg>
                </button>
                <div class="ytp-share-panel-inner-content">
                    <div class="ytp-share-panel-title" id="ytp-id-5">Поделиться</div>
                    <a class="ytp-share-panel-link ytp-no-contextmenu" target="_blank" title="Поделиться ссылкой"
                       aria-label="Поделиться ссылкой"></a><label class="ytp-share-panel-include-playlist"><input
                                class="ytp-share-panel-include-playlist-checkbox" type="checkbox" checked="true">В
                        составе плейлиста</label>
                    <div class="ytp-share-panel-loading-spinner">
                        <div class="ytp-spinner-container">
                            <div class="ytp-spinner-rotator">
                                <div class="ytp-spinner-left">
                                    <div class="ytp-spinner-circle"></div>
                                </div>
                                <div class="ytp-spinner-right">
                                    <div class="ytp-spinner-circle"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ytp-share-panel-service-buttons"></div>
                    <div class="ytp-share-panel-error">Ошибка. Повторите попытку позже.</div>
                </div>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="title m-b-md">
            Laravel
        </div>

        <div class="links">
            <a href="https://laravel.com/docs">Documentation</a>
            <a href="https://laracasts.com">Laracasts</a>
            <a href="https://laravel-news.com">News</a>
            <a href="https://forge.laravel.com">Forge</a>
            <a href="https://github.com/laravel/laravel">GitHub</a>
        </div>
    </div>
</div>
</body>
</html>
