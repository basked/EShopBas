<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
            <div class="container-fluid">
                <h2 class="h5 no-margin-bottom">Tables</h2>
            </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-10">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Курсы валют</li>

                    </ul>
                </div>
                <div class="col-lg-2">
                    <div class="dropdown show ">
                        <a class="btn btn-sm btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Обновить
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="<?php echo e(url('/banks_parse')); ?>">Банки</a>
                            <a class="dropdown-item" href="<?php echo e(url('/bank_offices_parse')); ?>">Офисы</a>
                            <a class="dropdown-item" href="<?php echo e(url('/bank_atms_parse')); ?>">Банкоматы</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(url('/bank_kurses_parse')); ?>">Курсы валют</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="no-padding-top">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="block margin-bottom-sm">
                            <div class="title"><strong><?php echo e($name); ?></strong> <span class="badge badge-light"><?php echo e($cnt); ?></span></div>

                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>Отделение банка</th>
                                        <th>Покупка</th>
                                        <th>Продажа</th>
                                        <th>Валюта</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $bankKurses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bankKurs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(\App\BankOffice::findOrFail($bankKurs->bank_offices_id)->name); ?></td>
                                            <td><?php echo e($bankKurs->pokupka); ?></td>
                                            <td><?php echo e($bankKurs->prodaja); ?></td>
                                            <td><?php echo e($bankKurs->currencies); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <?php $__env->startSection('js'); ?>
            <script src="<?php echo e(asset('css/dark-admin/js/front.js')); ?>"></script>
        <?php $__env->stopSection(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>