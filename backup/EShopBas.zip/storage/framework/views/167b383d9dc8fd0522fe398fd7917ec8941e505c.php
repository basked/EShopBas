<nav id="sidebar">
    <!-- Sidebar Header-->
    <div class="sidebar-header d-flex align-items-center">
        <div class="avatar"><img
                    src="<?php echo e(asset('css/dark-admin/img/avatar-6.jpg')); ?>"
                    alt="..." class="img-fluid rounded-circle"></div>
        <div class="title">
            <h1 class="h5">Mark Stephen</h1>
            <p>Web Designer</p>
        </div>
    </div>
    <!-- Sidebar Navidation Menus-->
    <span class="heading">Main</span>
    <ul class="list-unstyled">
        <li <?php echo e(Request::is('dashboard') ? "class=active" : ''); ?>><a href="<?php echo e(url('/dashboard')); ?>"><i class="icon-home"></i>Home </a></li>
        <li><a href="#tablesDropdown" aria-expanded=<?php echo e(Request::is(['tables','datatables']) ? 'true' : 'false'); ?> data-toggle="collapse"> <i class="icon-grid"></i>Tables
            </a>
            <ul id="tablesDropdown" class="collapse list-unstyled <?php echo e(Request::is(['tables','datatables']) ? 'show': ''); ?>">
                <li <?php echo e(Request::is('tables') ? "class=active" : ''); ?>><a href="<?php echo e(url('/tables')); ?>">Bootstrap table</a></li>
                <li <?php echo e(Request::is('datatables') ? "class=active" : ''); ?>><a href="<?php echo e(url('/datatables')); ?>">Datatable</a></li>
            </ul>
        </li>

        <li><a href="#chartsDropdown" aria-expanded=<?php echo e(Request::is(['charts','charts-gauge']) ? 'true' : 'false'); ?> data-toggle="collapse"> <i class="fa fa-bar-chart"></i>Charts
            </a>
            <ul id="chartsDropdown" class="collapse list-unstyled <?php echo e(Request::is(['charts','charts-gauge']) ? 'show': ''); ?>">
                <li <?php echo e(Request::is('charts') ? "class=active" : ''); ?>><a href="<?php echo e(url('/charts')); ?>">Charts</a></li>
                <li <?php echo e(Request::is('charts-gauge') ? "class=active" : ''); ?>><a href="<?php echo e(url('/charts-gauge')); ?>">Gauge + Sparkline</a></li>
            </ul>
        </li>

        <li><a href="#formsDropdown" aria-expanded=<?php echo e(Request::is(['forms','forms-advanced','forms-autocomplete','forms-texteditor','forms-dropzone']) ? 'true' : 'false'); ?> data-toggle="collapse"> <i class="icon-padnote"></i>Forms
            </a>
            <ul id="formsDropdown" class="collapse list-unstyled <?php echo e(Request::is(['forms','forms-advanced','forms-autocomplete','forms-texteditor','forms-dropzone']) ? 'show': ''); ?>">
                <li <?php echo e(Request::is('forms') ? "class=active" : ''); ?>><a href="<?php echo e(url('/forms')); ?>">Basic forms</a></li>
                <li <?php echo e(Request::is('forms-advanced') ? "class=active" : ''); ?>><a href="<?php echo e(url('/forms-advanced')); ?>">Advanced forms</a></li>
                <li <?php echo e(Request::is('forms-autocomplete') ? "class=active" : ''); ?>><a href="<?php echo e(url('/forms-autocomplete')); ?>">Autocomplete</a></li>
                <li <?php echo e(Request::is('forms-texteditor') ? "class=active" : ''); ?>><a href="<?php echo e(url('/forms-texteditor')); ?>">Text editor</a></li>
                <li <?php echo e(Request::is('forms-dropzone') ? "class=active" : ''); ?>><a href="<?php echo e(url('/forms-dropzone')); ?>">Files upload</a></li>
            </ul>
        </li>
        <li><a href="#componentsDropdown" aria-expanded=<?php echo e(Request::is(['components-cards','components-calendar','components-gallery','components-notifications','components-loading-buttons','components-preloader']) ? 'true' : 'false'); ?> data-toggle="collapse"> <i class="icon-light-bulb"></i>Components
            </a>
            <ul id="componentsDropdown" class="collapse list-unstyled <?php echo e(Request::is(['components-cards','components-calendar','components-gallery','components-notifications','components-loading-buttons','components-preloader']) ? 'show': ''); ?>">
                <li <?php echo e(Request::is('components-cards') ? "class=active" : ''); ?>><a href="<?php echo e(url('/components-cards')); ?>">Cards</a></li>
                <li <?php echo e(Request::is('components-calendar') ? "class=active" : ''); ?>><a href="<?php echo e(url('/components-calendar')); ?>">Calendar</a></li>
                <li <?php echo e(Request::is('components-gallery') ? "class=active" : ''); ?>><a href="<?php echo e(url('/components-gallery')); ?>">Gallery</a></li>
                <li <?php echo e(Request::is('components-notifications') ? "class=active" : ''); ?>><a href="<?php echo e(url('/components-notifications')); ?>">Notifications</a></li>
                <li <?php echo e(Request::is('components-loading-buttons') ? "class=active" : ''); ?>><a href="<?php echo e(url('/components-loading-buttons')); ?>">Loading buttons</a></li>
                <li <?php echo e(Request::is('components-preloader') ? "class=active" : ''); ?>><a href="<?php echo e(url('/components-preloader')); ?>">Preloaders</a></li>
            </ul>
        </li>
        <li><a href="#devextremeDropdown" aria-expanded=<?php echo e(Request::is(['dev-grid','template']) ? 'true' : 'false'); ?> data-toggle="collapse"> <i
                        class="icon-light-bulb"></i>Devextreme </a>
            <ul id="devextremeDropdown" class="collapse list-unstyled <?php echo e(Request::is(['dev-grid','template']) ? 'show' : ''); ?>">
                <li <?php echo e(Request::is('dev-grid') ? "class=active" : ''); ?>><a href="<?php echo e(url('/dev-grid')); ?>">Grid Custom DataSourse</a></li>
                <li <?php echo e(Request::is('template') ? "class=active" : ''); ?>><a href="<?php echo e(url('/template')); ?>">Grid API</a></li>
            </ul>
        </li>
        <li><a href="<?php echo e(url('/dashboard')); ?>"> <i class="icon-logout"></i>Login page </a></li>
    </ul>
    <span class="heading">Extras</span>
    <ul class="list-unstyled">
        <li><a href="#"> <i class="icon-settings"></i>Demo </a></li>
        <li><a href="#"> <i class="icon-writing-whiteboard"></i>Demo </a></li>
        <li><a href="#"> <i class="icon-chart"></i>Demo </a></li>
    </ul>

</nav>