<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('css/dark-admin/css/font.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/dark-admin/css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.default.premium.css')); ?>" rel="stylesheet" id="theme-stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>